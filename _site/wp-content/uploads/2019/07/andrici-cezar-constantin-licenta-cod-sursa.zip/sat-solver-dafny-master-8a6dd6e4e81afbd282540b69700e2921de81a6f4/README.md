I have added the following to the end of `~/.vscode/extensions/correctnesslab.dafny-vscode-0.15.0/dafny/dafny/dafny` to make it to compile in a resonable
time:

```
T1=$(date +%s)
"$MONO" "$DAFNY" -vcsCores 4 -errorLimit 1 "$@"
T2=$(date +%s)
TT=$((T2-T1))
notify-send "Dafny finished verifying!!! ${TT}s"
```
