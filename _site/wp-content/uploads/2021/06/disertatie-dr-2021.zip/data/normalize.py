import pandas as pd 
import scipy as sp
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from pandas import read_csv
from matplotlib import pyplot

df = read_csv('spss.csv')
# separate array into input and output components
df = df.set_index(['MS', 'Country', 'Group'])
# X = df.values[,:,]
arr_min = pd.DataFrame([0.,0.,0.,0.,0.] + [-2.5]*30 + [20000]*5 + [0]*5, index=df.columns).T
arr_max = pd.DataFrame([100.,100.,0.,0.,0.] + [2.5]*30 + [20000]*5 + [100]*5, index=df.columns).T
df1 = df.append(arr_min, ignore_index=True)
df1 = df1.append(arr_max, ignore_index=True)

scaler = MinMaxScaler(feature_range=(0, 100))
rescaledX = scaler.fit_transform(df1.values)[:-2]

dataset = pd.DataFrame(rescaledX, columns=df.columns, index=df.index)

dataset["GE_DIFF"] = dataset["GE2019"] - dataset["GE2014"]
dataset["RQ_DIFF"] = dataset["RQ2019"] - dataset["RQ2014"]
dataset["PS_DIFF"] = dataset["PS2019"] - dataset["PS2014"]
dataset["CC_DIFF"] = dataset["CC2019"] - dataset["CC2014"]
dataset["RL_DIFF"] = dataset["RL2019"] - dataset["RL2014"]
dataset["VA_DIFF"] = dataset["VA2019"] - dataset["VA2014"]


dataset["em_gdp"] = dataset["GDP2020"]-dataset["GDP2014"]
dataset["em_emp"] = dataset["EMP2020"]-dataset["EMP2014"]

delta_gdp_gr_covid = dataset["GDP2013"].mean()-dataset["GDP2008"].mean()
dataset["delta_gdp_gr"] = dataset["GDP2013"]-dataset["GDP2008"]
dataset["res_gdp_gr"] = (dataset["delta_gdp_gr"]-delta_gdp_gr_covid)/abs(delta_gdp_gr_covid)

delta_gdp_covid_eu28 = dataset["GDP2020"].mean()-dataset["GDP2019"].mean()
dataset["delta_gdp_covid"] = dataset["GDP2020"]-dataset["GDP2019"]
dataset["res_gdp_covid"] = (dataset["delta_gdp_covid"]-delta_gdp_covid_eu28)/abs(delta_gdp_covid_eu28)
dataset["res_gdp_diff"] = dataset["res_gdp_covid"] - dataset["res_gdp_gr"]

delta_emp_gr_eu28 = dataset["EMP2013"].mean()-dataset["EMP2008"].mean()
dataset["delta_emp_gr"] = dataset["EMP2013"]-dataset["EMP2008"]
dataset["res_emp_gr"] = (dataset["delta_emp_gr"]-delta_emp_gr_eu28)/abs(delta_emp_gr_eu28)

delta_emp_covid_eu28 = dataset["EMP2020"].mean() - dataset["EMP2019"].mean()
dataset["delta_emp_covid"] = dataset["EMP2020"]-dataset["EMP2019"]
dataset["res_emp_covid"] = (dataset["delta_emp_covid"]-delta_emp_covid_eu28)/abs(delta_emp_covid_eu28)

dataset["res_emp_diff"] = dataset["res_emp_covid"] - dataset["res_emp_gr"]


np.set_printoptions(precision=3)
dataset.to_csv("spss_normalized.csv")
